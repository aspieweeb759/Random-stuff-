extern const GeoLayout toad_geo[];
extern Vtx toad_000_offset_003_mesh_vtx_0[31];
extern Gfx toad_000_offset_003_mesh_tri_0[];
extern Vtx toad_000_offset_003_mesh_vtx_1[59];
extern Gfx toad_000_offset_003_mesh_tri_1[];
extern Vtx toad_003_offset_mesh_vtx_0[46];
extern Gfx toad_003_offset_mesh_tri_0[];
extern Vtx toad_003_offset_mesh_vtx_1[44];
extern Gfx toad_003_offset_mesh_tri_1[];
extern Vtx toad_000_offset_006_mesh_vtx_0[30];
extern Gfx toad_000_offset_006_mesh_tri_0[];
extern Vtx toad_000_offset_009_mesh_vtx_0[30];
extern Gfx toad_000_offset_009_mesh_tri_0[];
extern Vtx toad_000_offset_011_mesh_vtx_0[59];
extern Gfx toad_000_offset_011_mesh_tri_0[];
extern Vtx toad_000_offset_013_mesh_vtx_0[58];
extern Gfx toad_000_offset_013_mesh_tri_0[];

extern Gfx toad_000_offset_003_mesh[];
extern Gfx toad_003_offset_mesh[];
extern Gfx toad_000_offset_006_mesh[];
extern Gfx toad_000_offset_009_mesh[];
extern Gfx toad_000_offset_011_mesh[];
extern Gfx toad_000_offset_013_mesh[];
extern Gfx toad_material_revert_render_settings[];

